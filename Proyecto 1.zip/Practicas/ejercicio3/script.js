document.getElementById("btnRojo")

document.getElementById("btnRojo").onclick=function(){
document.body.style.background="red";
};

document.getElementById("btnAzul").onclick=function(){
document.body.style.background="blue";
};

document.getElementById("btnVerde").onclick=function(){
document.body.style.background="green";
};