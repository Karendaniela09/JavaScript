document.getElementById("btnSumar").onclick=function(){

let n1=Number(document.getElementById("numero1").value);
let n2=Number(document.getElementById("numero2").value);

document.getElementById("resultadoSuma").textContent=
n1+n2;

};