let tiempo=0;
let intervalo;

document.getElementById("btnIniciar")
.addEventListener("click", function(){

intervalo=setInterval(function(){

tiempo++;

document.getElementById("tiempo").textContent=tiempo;

},1000);

});

document.getElementById("btnDetener")
.addEventListener("click", function(){

clearInterval(intervalo);

});

document.getElementById("btnReiniciar")
.addEventListener("click", function(){

clearInterval(intervalo);

tiempo=0;

document.getElementById("tiempo").textContent=tiempo;

});