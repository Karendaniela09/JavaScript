document.getElementById("btnMensaje")
.addEventListener("click", function(){

document.getElementById("resultado").textContent =
"Hola mundo desde JavaScript";

});