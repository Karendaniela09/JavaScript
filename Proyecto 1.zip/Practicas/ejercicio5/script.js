document.getElementById("btnAgregar")
.addEventListener("click", function(){

let tarea=document.getElementById("tarea").value;

let li=document.createElement("li");

li.textContent=tarea;

document.getElementById("listaTareas").appendChild(li);

});