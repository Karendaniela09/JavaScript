document.getElementById("btnAleatorio")
.addEventListener("click", function(){

let numero = Math.floor(Math.random() * 100) + 1;

document.getElementById("numeroAleatorio").textContent =
"Número generado: " + numero;

});