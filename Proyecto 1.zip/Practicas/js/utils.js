export function obtenerElemento(id){
    return document.getElementById(id);
}

export function mostrarTexto(id, texto){
    obtenerElemento(id).textContent = texto;
}

export function obtenerValor(id){
    return obtenerElemento(id).value;
}