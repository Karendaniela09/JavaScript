export class Contador{

#valor = 0;

incrementar(){
    this.#valor++;
}

decrementar(){
    this.#valor--;
}

obtenerValor(){
    return this.#valor;
}

}