obtenerElemento("btnCalcular").addEventListener("click", () => {

let n1 = Number(obtenerElemento("num1").value);
let n2 = Number(obtenerElemento("num2").value);
let operacion = obtenerElemento("operacion").value;

let resultado;

if(operacion==="+") resultado = calculadora.sumar(n1,n2);
if(operacion==="-") resultado = calculadora.restar(n1,n2);
if(operacion==="*") resultado = calculadora.multiplicar(n1,n2);
if(operacion==="/") resultado = calculadora.dividir(n1,n2);

mostrarTexto("resultadoCalc", resultado);

});