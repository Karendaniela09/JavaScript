document.getElementById("btnCalcular")
.addEventListener("click", function(){

let num1=Number(document.getElementById("num1").value);
let num2=Number(document.getElementById("num2").value);

let operacion=document.getElementById("operacion").value;

let resultado;

if(operacion==="+") resultado=num1+num2;
if(operacion==="-") resultado=num1-num2;
if(operacion==="*") resultado=num1*num2;
if(operacion==="/") resultado=num1/num2;

document.getElementById("resultadoCalc").textContent=
"Resultado: "+resultado;

});